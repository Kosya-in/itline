﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Форма переопределяет dispose для очистки списка компонентов.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Является обязательной для конструктора форм Windows Forms
    Private components As System.ComponentModel.IContainer

    'Примечание: следующая процедура является обязательной для конструктора форм Windows Forms
    'Для ее изменения используйте конструктор форм Windows Form.  
    'Не изменяйте ее в редакторе исходного кода.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form3))
        Me.U4et_oborudovanieDataSet = New Uchet_oborudovanie.U4et_oborudovanieDataSet()
        Me.ПоставкаBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ПоставкаTableAdapter = New Uchet_oborudovanie.U4et_oborudovanieDataSetTableAdapters.ПоставкаTableAdapter()
        Me.TableAdapterManager = New Uchet_oborudovanie.U4et_oborudovanieDataSetTableAdapters.TableAdapterManager()
        Me.ПоставкаBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.ПоставкаBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.ПоставкаDataGridView = New System.Windows.Forms.DataGridView()
        Me.ПоставщикBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ПоставщикTableAdapter = New Uchet_oborudovanie.U4et_oborudovanieDataSetTableAdapters.ПоставщикTableAdapter()
        Me.ОборудованиеBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ОборудованиеTableAdapter = New Uchet_oborudovanie.U4et_oborudovanieDataSetTableAdapters.ОборудованиеTableAdapter()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.U4et_oborudovanieDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ПоставкаBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ПоставкаBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ПоставкаBindingNavigator.SuspendLayout()
        CType(Me.ПоставкаDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ПоставщикBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ОборудованиеBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'U4et_oborudovanieDataSet
        '
        Me.U4et_oborudovanieDataSet.DataSetName = "U4et_oborudovanieDataSet"
        Me.U4et_oborudovanieDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'ПоставкаBindingSource
        '
        Me.ПоставкаBindingSource.DataMember = "Поставка"
        Me.ПоставкаBindingSource.DataSource = Me.U4et_oborudovanieDataSet
        '
        'ПоставкаTableAdapter
        '
        Me.ПоставкаTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.UpdateOrder = Uchet_oborudovanie.U4et_oborudovanieDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        Me.TableAdapterManager.Акт_списанияTableAdapter = Nothing
        Me.TableAdapterManager.КассаTableAdapter = Nothing
        Me.TableAdapterManager.ОборудованиеTableAdapter = Me.ОборудованиеTableAdapter
        Me.TableAdapterManager.ПоставкаTableAdapter = Me.ПоставкаTableAdapter
        Me.TableAdapterManager.ПоставщикTableAdapter = Me.ПоставщикTableAdapter
        Me.TableAdapterManager.Расход_кассаTableAdapter = Nothing
        Me.TableAdapterManager.СкладTableAdapter = Nothing
        '
        'ПоставкаBindingNavigator
        '
        Me.ПоставкаBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.ПоставкаBindingNavigator.BindingSource = Me.ПоставкаBindingSource
        Me.ПоставкаBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.ПоставкаBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.ПоставкаBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.ПоставкаBindingNavigatorSaveItem})
        Me.ПоставкаBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.ПоставкаBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.ПоставкаBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.ПоставкаBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.ПоставкаBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.ПоставкаBindingNavigator.Name = "ПоставкаBindingNavigator"
        Me.ПоставкаBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.ПоставкаBindingNavigator.Size = New System.Drawing.Size(595, 25)
        Me.ПоставкаBindingNavigator.TabIndex = 0
        Me.ПоставкаBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Переместить в начало"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Переместить назад"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Положение"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 23)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Текущее положение"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(43, 15)
        Me.BindingNavigatorCountItem.Text = "для {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Общее число элементов"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 6)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 20)
        Me.BindingNavigatorMoveNextItem.Text = "Переместить вперед"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 20)
        Me.BindingNavigatorMoveLastItem.Text = "Переместить в конец"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 6)
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Добавить"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 20)
        Me.BindingNavigatorDeleteItem.Text = "Удалить"
        '
        'ПоставкаBindingNavigatorSaveItem
        '
        Me.ПоставкаBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ПоставкаBindingNavigatorSaveItem.Image = CType(resources.GetObject("ПоставкаBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.ПоставкаBindingNavigatorSaveItem.Name = "ПоставкаBindingNavigatorSaveItem"
        Me.ПоставкаBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 23)
        Me.ПоставкаBindingNavigatorSaveItem.Text = "Сохранить данные"
        '
        'ПоставкаDataGridView
        '
        Me.ПоставкаDataGridView.AutoGenerateColumns = False
        Me.ПоставкаDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.ПоставкаDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4, Me.DataGridViewTextBoxColumn5, Me.DataGridViewTextBoxColumn6})
        Me.ПоставкаDataGridView.DataSource = Me.ПоставкаBindingSource
        Me.ПоставкаDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ПоставкаDataGridView.Location = New System.Drawing.Point(0, 25)
        Me.ПоставкаDataGridView.Name = "ПоставкаDataGridView"
        Me.ПоставкаDataGridView.Size = New System.Drawing.Size(595, 367)
        Me.ПоставкаDataGridView.TabIndex = 1
        '
        'ПоставщикBindingSource
        '
        Me.ПоставщикBindingSource.DataMember = "Поставщик"
        Me.ПоставщикBindingSource.DataSource = Me.U4et_oborudovanieDataSet
        '
        'ПоставщикTableAdapter
        '
        Me.ПоставщикTableAdapter.ClearBeforeFill = True
        '
        'ОборудованиеBindingSource
        '
        Me.ОборудованиеBindingSource.DataMember = "Оборудование"
        Me.ОборудованиеBindingSource.DataSource = Me.U4et_oborudovanieDataSet
        '
        'ОборудованиеTableAdapter
        '
        Me.ОборудованиеTableAdapter.ClearBeforeFill = True
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "ID_postavka"
        Me.DataGridViewTextBoxColumn1.HeaderText = "№"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        Me.DataGridViewTextBoxColumn1.Width = 50
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "Postavshik"
        Me.DataGridViewTextBoxColumn2.DataSource = Me.ПоставщикBindingSource
        Me.DataGridViewTextBoxColumn2.DisplayMember = "Name"
        Me.DataGridViewTextBoxColumn2.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.ComboBox
        Me.DataGridViewTextBoxColumn2.HeaderText = "Поставщик"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.DataGridViewTextBoxColumn2.ValueMember = "ID_postavshik"
        Me.DataGridViewTextBoxColumn2.Width = 120
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "Date_postavka"
        Me.DataGridViewTextBoxColumn3.HeaderText = "Дата поставки"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "Oborudovanie"
        Me.DataGridViewTextBoxColumn4.DataSource = Me.ОборудованиеBindingSource
        Me.DataGridViewTextBoxColumn4.DisplayMember = "Name"
        Me.DataGridViewTextBoxColumn4.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.ComboBox
        Me.DataGridViewTextBoxColumn4.HeaderText = "Товар"
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.DataGridViewTextBoxColumn4.ValueMember = "Id_oborudovanie"
        Me.DataGridViewTextBoxColumn4.Width = 120
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.DataPropertyName = "Kolichestvo"
        Me.DataGridViewTextBoxColumn5.HeaderText = "Количество"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.Width = 80
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.DataPropertyName = "Stoimost"
        Me.DataGridViewTextBoxColumn6.HeaderText = "Цена"
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        Me.DataGridViewTextBoxColumn6.Width = 80
        '
        'Form3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(595, 392)
        Me.Controls.Add(Me.ПоставкаDataGridView)
        Me.Controls.Add(Me.ПоставкаBindingNavigator)
        Me.Name = "Form3"
        Me.Text = "Поставка"
        CType(Me.U4et_oborudovanieDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ПоставкаBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ПоставкаBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ПоставкаBindingNavigator.ResumeLayout(False)
        Me.ПоставкаBindingNavigator.PerformLayout()
        CType(Me.ПоставкаDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ПоставщикBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ОборудованиеBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents U4et_oborudovanieDataSet As U4et_oborudovanieDataSet
    Friend WithEvents ПоставкаBindingSource As BindingSource
    Friend WithEvents ПоставкаTableAdapter As U4et_oborudovanieDataSetTableAdapters.ПоставкаTableAdapter
    Friend WithEvents TableAdapterManager As U4et_oborudovanieDataSetTableAdapters.TableAdapterManager
    Friend WithEvents ПоставкаBindingNavigator As BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As ToolStripSeparator
    Friend WithEvents ПоставкаBindingNavigatorSaveItem As ToolStripButton
    Friend WithEvents ПоставкаDataGridView As DataGridView
    Friend WithEvents ПоставщикTableAdapter As U4et_oborudovanieDataSetTableAdapters.ПоставщикTableAdapter
    Friend WithEvents ПоставщикBindingSource As BindingSource
    Friend WithEvents ОборудованиеTableAdapter As U4et_oborudovanieDataSetTableAdapters.ОборудованиеTableAdapter
    Friend WithEvents ОборудованиеBindingSource As BindingSource
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewComboBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As DataGridViewComboBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As DataGridViewTextBoxColumn
End Class
