﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form6
    Inherits System.Windows.Forms.Form

    'Форма переопределяет dispose для очистки списка компонентов.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Является обязательной для конструктора форм Windows Forms
    Private components As System.ComponentModel.IContainer

    'Примечание: следующая процедура является обязательной для конструктора форм Windows Forms
    'Для ее изменения используйте конструктор форм Windows Form.  
    'Не изменяйте ее в редакторе исходного кода.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim ID_postavkaLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form6))
        Me.U4et_oborudovanieDataSet = New Uchet_oborudovanie.U4et_oborudovanieDataSet()
        Me.ПоставкаBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ПоставкаTableAdapter = New Uchet_oborudovanie.U4et_oborudovanieDataSetTableAdapters.ПоставкаTableAdapter()
        Me.TableAdapterManager = New Uchet_oborudovanie.U4et_oborudovanieDataSetTableAdapters.TableAdapterManager()
        Me.ОборудованиеTableAdapter = New Uchet_oborudovanie.U4et_oborudovanieDataSetTableAdapters.ОборудованиеTableAdapter()
        Me.ПоставщикTableAdapter = New Uchet_oborudovanie.U4et_oborudovanieDataSetTableAdapters.ПоставщикTableAdapter()
        Me.ПоставкаDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.ПоставщикBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.ОборудованиеBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ID_postavkaTextBox = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.QueriesTableAdapter1 = New Uchet_oborudovanie.U4et_oborudovanieDataSetTableAdapters.QueriesTableAdapter()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        ID_postavkaLabel = New System.Windows.Forms.Label()
        CType(Me.U4et_oborudovanieDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ПоставкаBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ПоставкаDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ПоставщикBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ОборудованиеBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ID_postavkaLabel
        '
        ID_postavkaLabel.AutoSize = True
        ID_postavkaLabel.Location = New System.Drawing.Point(556, 101)
        ID_postavkaLabel.Name = "ID_postavkaLabel"
        ID_postavkaLabel.Size = New System.Drawing.Size(137, 13)
        ID_postavkaLabel.TabIndex = 1
        ID_postavkaLabel.Text = "Введите номер поставки:"
        '
        'U4et_oborudovanieDataSet
        '
        Me.U4et_oborudovanieDataSet.DataSetName = "U4et_oborudovanieDataSet"
        Me.U4et_oborudovanieDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'ПоставкаBindingSource
        '
        Me.ПоставкаBindingSource.DataMember = "Поставка"
        Me.ПоставкаBindingSource.DataSource = Me.U4et_oborudovanieDataSet
        '
        'ПоставкаTableAdapter
        '
        Me.ПоставкаTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.UpdateOrder = Uchet_oborudovanie.U4et_oborudovanieDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        Me.TableAdapterManager.Акт_списанияTableAdapter = Nothing
        Me.TableAdapterManager.КассаTableAdapter = Nothing
        Me.TableAdapterManager.ОборудованиеTableAdapter = Me.ОборудованиеTableAdapter
        Me.TableAdapterManager.ПоставкаTableAdapter = Me.ПоставкаTableAdapter
        Me.TableAdapterManager.ПоставщикTableAdapter = Me.ПоставщикTableAdapter
        Me.TableAdapterManager.Расход_кассаTableAdapter = Nothing
        Me.TableAdapterManager.СкладTableAdapter = Nothing
        '
        'ОборудованиеTableAdapter
        '
        Me.ОборудованиеTableAdapter.ClearBeforeFill = True
        '
        'ПоставщикTableAdapter
        '
        Me.ПоставщикTableAdapter.ClearBeforeFill = True
        '
        'ПоставкаDataGridView
        '
        Me.ПоставкаDataGridView.AutoGenerateColumns = False
        Me.ПоставкаDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.ПоставкаDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4, Me.DataGridViewTextBoxColumn5, Me.DataGridViewTextBoxColumn6})
        Me.ПоставкаDataGridView.DataSource = Me.ПоставкаBindingSource
        Me.ПоставкаDataGridView.Location = New System.Drawing.Point(0, -1)
        Me.ПоставкаDataGridView.Name = "ПоставкаDataGridView"
        Me.ПоставкаDataGridView.Size = New System.Drawing.Size(525, 345)
        Me.ПоставкаDataGridView.TabIndex = 1
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "ID_postavka"
        Me.DataGridViewTextBoxColumn1.HeaderText = "Номер поставки"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        Me.DataGridViewTextBoxColumn1.Width = 80
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "Postavshik"
        Me.DataGridViewTextBoxColumn2.DataSource = Me.ПоставщикBindingSource
        Me.DataGridViewTextBoxColumn2.DisplayMember = "Name"
        Me.DataGridViewTextBoxColumn2.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.[Nothing]
        Me.DataGridViewTextBoxColumn2.HeaderText = "Поставщик"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.DataGridViewTextBoxColumn2.ValueMember = "ID_postavshik"
        '
        'ПоставщикBindingSource
        '
        Me.ПоставщикBindingSource.DataMember = "Поставщик"
        Me.ПоставщикBindingSource.DataSource = Me.U4et_oborudovanieDataSet
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "Date_postavka"
        Me.DataGridViewTextBoxColumn3.HeaderText = "Дата"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.Width = 80
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "Oborudovanie"
        Me.DataGridViewTextBoxColumn4.DataSource = Me.ОборудованиеBindingSource
        Me.DataGridViewTextBoxColumn4.DisplayMember = "Name"
        Me.DataGridViewTextBoxColumn4.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.[Nothing]
        Me.DataGridViewTextBoxColumn4.HeaderText = "Товар"
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.DataGridViewTextBoxColumn4.ValueMember = "Id_oborudovanie"
        Me.DataGridViewTextBoxColumn4.Width = 150
        '
        'ОборудованиеBindingSource
        '
        Me.ОборудованиеBindingSource.DataMember = "Оборудование"
        Me.ОборудованиеBindingSource.DataSource = Me.U4et_oborudovanieDataSet
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.DataPropertyName = "Kolichestvo"
        Me.DataGridViewTextBoxColumn5.HeaderText = "Количество"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.DataPropertyName = "Stoimost"
        Me.DataGridViewTextBoxColumn6.HeaderText = "Сумма (сом)"
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        Me.DataGridViewTextBoxColumn6.Width = 90
        '
        'ID_postavkaTextBox
        '
        Me.ID_postavkaTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ПоставкаBindingSource, "ID_postavka", True))
        Me.ID_postavkaTextBox.Location = New System.Drawing.Point(575, 135)
        Me.ID_postavkaTextBox.Name = "ID_postavkaTextBox"
        Me.ID_postavkaTextBox.Size = New System.Drawing.Size(100, 20)
        Me.ID_postavkaTextBox.TabIndex = 2
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(559, 174)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(134, 65)
        Me.Button1.TabIndex = 3
        Me.Button1.Text = "Возврат"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(559, 12)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(104, 64)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 4
        Me.PictureBox1.TabStop = False
        '
        'Form6
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(705, 340)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(ID_postavkaLabel)
        Me.Controls.Add(Me.ID_postavkaTextBox)
        Me.Controls.Add(Me.ПоставкаDataGridView)
        Me.Name = "Form6"
        Me.Text = "Возврат товара"
        CType(Me.U4et_oborudovanieDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ПоставкаBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ПоставкаDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ПоставщикBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ОборудованиеBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents U4et_oborudovanieDataSet As U4et_oborudovanieDataSet
    Friend WithEvents ПоставкаBindingSource As BindingSource
    Friend WithEvents ПоставкаTableAdapter As U4et_oborudovanieDataSetTableAdapters.ПоставкаTableAdapter
    Friend WithEvents TableAdapterManager As U4et_oborudovanieDataSetTableAdapters.TableAdapterManager
    Friend WithEvents ПоставкаDataGridView As DataGridView
    Friend WithEvents ID_postavkaTextBox As TextBox
    Friend WithEvents Button1 As Button
    Friend WithEvents QueriesTableAdapter1 As U4et_oborudovanieDataSetTableAdapters.QueriesTableAdapter
    Friend WithEvents ПоставщикTableAdapter As U4et_oborudovanieDataSetTableAdapters.ПоставщикTableAdapter
    Friend WithEvents ПоставщикBindingSource As BindingSource
    Friend WithEvents ОборудованиеTableAdapter As U4et_oborudovanieDataSetTableAdapters.ОборудованиеTableAdapter
    Friend WithEvents ОборудованиеBindingSource As BindingSource
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewComboBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As DataGridViewComboBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As DataGridViewTextBoxColumn
    Friend WithEvents PictureBox1 As PictureBox
End Class
