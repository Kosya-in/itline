﻿Public Class Form1
    Private Sub ОборудованиеBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles ОборудованиеBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.ОборудованиеBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.U4et_oborudovanieDataSet)

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: данная строка кода позволяет загрузить данные в таблицу "U4et_oborudovanieDataSet.Оборудование". При необходимости она может быть перемещена или удалена.
        Me.ОборудованиеTableAdapter.Fill(Me.U4et_oborudovanieDataSet.Оборудование)

    End Sub
End Class
