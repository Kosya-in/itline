﻿Public Class Form5
    Private Sub Form5_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: данная строка кода позволяет загрузить данные в таблицу "U4et_oborudovanieDataSet.Расход_касса". При необходимости она может быть перемещена или удалена.
        Me.Расход_кассаTableAdapter.Fill(Me.U4et_oborudovanieDataSet.Расход_касса)

        Me.ReportViewer1.RefreshReport()
    End Sub
End Class