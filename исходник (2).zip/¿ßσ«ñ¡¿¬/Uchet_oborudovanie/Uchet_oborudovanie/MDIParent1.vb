﻿Imports System.Windows.Forms

Public Class MDIParent1
    Private Sub MDIParent1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: данная строка кода позволяет загрузить данные в таблицу "U4et_oborudovanieDataSet.Касса". При необходимости она может быть перемещена или удалена.
        Me.КассаTableAdapter.Fill(Me.U4et_oborudovanieDataSet.Касса)
        ToolStripStatusLabel1.Text = KassaTextBox.Text
        KassaTextBox.Visible = False
    End Sub

    Private Sub ТоварToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ТоварToolStripMenuItem.Click
        Form1.MdiParent = Me
        Form1.Show()
    End Sub

    Private Sub ПоставщикиToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ПоставщикиToolStripMenuItem.Click
        Form2.MdiParent = Me
        Form2.Show()
    End Sub

    Private Sub ПоставкаToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ПоставкаToolStripMenuItem.Click
        Form3.MdiParent = Me
        Form3.Show()
    End Sub

    Private Sub СписаниеToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles СписаниеToolStripMenuItem.Click
        Form4.MdiParent = Me
        Form4.Show()
    End Sub

    Private Sub СкладToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles СкладToolStripMenuItem.Click
        Form7.MdiParent = Me
        Form7.Show()
    End Sub

    Private Sub ОтчетОРасходныхНакладныхToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ОтчетОРасходныхНакладныхToolStripMenuItem.Click
        Form5.MdiParent = Me
        Form5.Show()
    End Sub

    Private Sub ВозвратТовараToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ВозвратТовараToolStripMenuItem.Click
        Form6.MdiParent = Me
        Form6.Show()
    End Sub

    Private Sub ОтчетОВозвращенныхТоварахToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ОтчетОВозвращенныхТоварахToolStripMenuItem.Click
        Form8.MdiParent = Me
        Form8.Show()
    End Sub

    Private Sub КассаBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles КассаBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.КассаBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.U4et_oborudovanieDataSet)

    End Sub

    Private Sub ToolStripMenuItem3_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem3.Click
        Form9.MdiParent = Me
        Form9.Show()
    End Sub
End Class
