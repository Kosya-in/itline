﻿Public Class Form4
    Private Sub Акт_списанияBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles Акт_списанияBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.Акт_списанияBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.U4et_oborudovanieDataSet)

    End Sub

    Private Sub Form4_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: данная строка кода позволяет загрузить данные в таблицу "U4et_oborudovanieDataSet.Оборудование". При необходимости она может быть перемещена или удалена.
        Me.ОборудованиеTableAdapter.Fill(Me.U4et_oborudovanieDataSet.Оборудование)
        'TODO: данная строка кода позволяет загрузить данные в таблицу "U4et_oborudovanieDataSet.Акт_списания". При необходимости она может быть перемещена или удалена.
        Me.Акт_списанияTableAdapter.Fill(Me.U4et_oborudovanieDataSet.Акт_списания)

    End Sub
End Class