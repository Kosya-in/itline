﻿Public Class Form2
    Private Sub ПоставщикBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles ПоставщикBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.ПоставщикBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.U4et_oborudovanieDataSet)

    End Sub

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: данная строка кода позволяет загрузить данные в таблицу "U4et_oborudovanieDataSet.Поставщик". При необходимости она может быть перемещена или удалена.
        Me.ПоставщикTableAdapter.Fill(Me.U4et_oborudovanieDataSet.Поставщик)

    End Sub
End Class