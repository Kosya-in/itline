﻿Public Class Form7
    Private Sub Form7_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: данная строка кода позволяет загрузить данные в таблицу "U4et_oborudovanieDataSet.Report_sklad". При необходимости она может быть перемещена или удалена.
        Me.Report_skladTableAdapter.Fill(Me.U4et_oborudovanieDataSet.Report_sklad)

        Me.ReportViewer1.RefreshReport()
    End Sub
End Class