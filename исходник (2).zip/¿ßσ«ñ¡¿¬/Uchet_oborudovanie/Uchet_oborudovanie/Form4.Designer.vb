﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form4
    Inherits System.Windows.Forms.Form

    'Форма переопределяет dispose для очистки списка компонентов.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Является обязательной для конструктора форм Windows Forms
    Private components As System.ComponentModel.IContainer

    'Примечание: следующая процедура является обязательной для конструктора форм Windows Forms
    'Для ее изменения используйте конструктор форм Windows Form.  
    'Не изменяйте ее в редакторе исходного кода.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form4))
        Me.U4et_oborudovanieDataSet = New Uchet_oborudovanie.U4et_oborudovanieDataSet()
        Me.Акт_списанияBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Акт_списанияTableAdapter = New Uchet_oborudovanie.U4et_oborudovanieDataSetTableAdapters.Акт_списанияTableAdapter()
        Me.TableAdapterManager = New Uchet_oborudovanie.U4et_oborudovanieDataSetTableAdapters.TableAdapterManager()
        Me.ОборудованиеTableAdapter = New Uchet_oborudovanie.U4et_oborudovanieDataSetTableAdapters.ОборудованиеTableAdapter()
        Me.Акт_списанияBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.Акт_списанияBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.Акт_списанияDataGridView = New System.Windows.Forms.DataGridView()
        Me.ОборудованиеBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.U4et_oborudovanieDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Акт_списанияBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Акт_списанияBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Акт_списанияBindingNavigator.SuspendLayout()
        CType(Me.Акт_списанияDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ОборудованиеBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'U4et_oborudovanieDataSet
        '
        Me.U4et_oborudovanieDataSet.DataSetName = "U4et_oborudovanieDataSet"
        Me.U4et_oborudovanieDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Акт_списанияBindingSource
        '
        Me.Акт_списанияBindingSource.DataMember = "Акт_списания"
        Me.Акт_списанияBindingSource.DataSource = Me.U4et_oborudovanieDataSet
        '
        'Акт_списанияTableAdapter
        '
        Me.Акт_списанияTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.UpdateOrder = Uchet_oborudovanie.U4et_oborudovanieDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        Me.TableAdapterManager.Акт_списанияTableAdapter = Me.Акт_списанияTableAdapter
        Me.TableAdapterManager.КассаTableAdapter = Nothing
        Me.TableAdapterManager.ОборудованиеTableAdapter = Me.ОборудованиеTableAdapter
        Me.TableAdapterManager.ПоставкаTableAdapter = Nothing
        Me.TableAdapterManager.ПоставщикTableAdapter = Nothing
        Me.TableAdapterManager.Расход_кассаTableAdapter = Nothing
        Me.TableAdapterManager.СкладTableAdapter = Nothing
        '
        'ОборудованиеTableAdapter
        '
        Me.ОборудованиеTableAdapter.ClearBeforeFill = True
        '
        'Акт_списанияBindingNavigator
        '
        Me.Акт_списанияBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.Акт_списанияBindingNavigator.BindingSource = Me.Акт_списанияBindingSource
        Me.Акт_списанияBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.Акт_списанияBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.Акт_списанияBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.Акт_списанияBindingNavigatorSaveItem})
        Me.Акт_списанияBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.Акт_списанияBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.Акт_списанияBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.Акт_списанияBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.Акт_списанияBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.Акт_списанияBindingNavigator.Name = "Акт_списанияBindingNavigator"
        Me.Акт_списанияBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.Акт_списанияBindingNavigator.Size = New System.Drawing.Size(617, 25)
        Me.Акт_списанияBindingNavigator.TabIndex = 0
        Me.Акт_списанияBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Добавить"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(43, 22)
        Me.BindingNavigatorCountItem.Text = "для {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Общее число элементов"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Удалить"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Переместить в начало"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Переместить назад"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Положение"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 23)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Текущее положение"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Переместить вперед"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Переместить в конец"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'Акт_списанияBindingNavigatorSaveItem
        '
        Me.Акт_списанияBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.Акт_списанияBindingNavigatorSaveItem.Image = CType(resources.GetObject("Акт_списанияBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.Акт_списанияBindingNavigatorSaveItem.Name = "Акт_списанияBindingNavigatorSaveItem"
        Me.Акт_списанияBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.Акт_списанияBindingNavigatorSaveItem.Text = "Сохранить данные"
        '
        'Акт_списанияDataGridView
        '
        Me.Акт_списанияDataGridView.AutoGenerateColumns = False
        Me.Акт_списанияDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Акт_списанияDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4, Me.DataGridViewTextBoxColumn5})
        Me.Акт_списанияDataGridView.DataSource = Me.Акт_списанияBindingSource
        Me.Акт_списанияDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Акт_списанияDataGridView.Location = New System.Drawing.Point(0, 25)
        Me.Акт_списанияDataGridView.Name = "Акт_списанияDataGridView"
        Me.Акт_списанияDataGridView.Size = New System.Drawing.Size(617, 382)
        Me.Акт_списанияDataGridView.TabIndex = 1
        '
        'ОборудованиеBindingSource
        '
        Me.ОборудованиеBindingSource.DataMember = "Оборудование"
        Me.ОборудованиеBindingSource.DataSource = Me.U4et_oborudovanieDataSet
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "ID_akt_spisanie"
        Me.DataGridViewTextBoxColumn1.HeaderText = "№"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        Me.DataGridViewTextBoxColumn1.Width = 50
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "Oborudovanie"
        Me.DataGridViewTextBoxColumn2.DataSource = Me.ОборудованиеBindingSource
        Me.DataGridViewTextBoxColumn2.DisplayMember = "Name"
        Me.DataGridViewTextBoxColumn2.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.ComboBox
        Me.DataGridViewTextBoxColumn2.HeaderText = "Товар"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.DataGridViewTextBoxColumn2.ValueMember = "Id_oborudovanie"
        Me.DataGridViewTextBoxColumn2.Width = 120
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "Kolichestvo"
        Me.DataGridViewTextBoxColumn3.HeaderText = "Количество"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "Date_spisanie"
        Me.DataGridViewTextBoxColumn4.HeaderText = "Дата возврата"
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.DataPropertyName = "Prichina"
        Me.DataGridViewTextBoxColumn5.HeaderText = "Причина"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.Width = 200
        '
        'Form4
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(617, 407)
        Me.Controls.Add(Me.Акт_списанияDataGridView)
        Me.Controls.Add(Me.Акт_списанияBindingNavigator)
        Me.Name = "Form4"
        Me.Text = "Списание товара"
        CType(Me.U4et_oborudovanieDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Акт_списанияBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Акт_списанияBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Акт_списанияBindingNavigator.ResumeLayout(False)
        Me.Акт_списанияBindingNavigator.PerformLayout()
        CType(Me.Акт_списанияDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ОборудованиеBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents U4et_oborudovanieDataSet As U4et_oborudovanieDataSet
    Friend WithEvents Акт_списанияBindingSource As BindingSource
    Friend WithEvents Акт_списанияTableAdapter As U4et_oborudovanieDataSetTableAdapters.Акт_списанияTableAdapter
    Friend WithEvents TableAdapterManager As U4et_oborudovanieDataSetTableAdapters.TableAdapterManager
    Friend WithEvents Акт_списанияBindingNavigator As BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As ToolStripSeparator
    Friend WithEvents Акт_списанияBindingNavigatorSaveItem As ToolStripButton
    Friend WithEvents ОборудованиеTableAdapter As U4et_oborudovanieDataSetTableAdapters.ОборудованиеTableAdapter
    Friend WithEvents Акт_списанияDataGridView As DataGridView
    Friend WithEvents ОборудованиеBindingSource As BindingSource
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewComboBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As DataGridViewTextBoxColumn
End Class
