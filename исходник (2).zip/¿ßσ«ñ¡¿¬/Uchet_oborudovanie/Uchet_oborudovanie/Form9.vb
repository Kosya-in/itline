﻿Public Class Form9
    Private Sub Form9_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: данная строка кода позволяет загрузить данные в таблицу "U4et_oborudovanieDataSet.report_spicanie". При необходимости она может быть перемещена или удалена.
        Me.report_spicanieTableAdapter.Fill(Me.U4et_oborudovanieDataSet.report_spicanie)

        Me.ReportViewer1.RefreshReport()
    End Sub
End Class