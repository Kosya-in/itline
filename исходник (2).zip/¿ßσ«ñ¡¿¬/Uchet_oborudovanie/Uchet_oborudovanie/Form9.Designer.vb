﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form9
    Inherits System.Windows.Forms.Form

    'Форма переопределяет dispose для очистки списка компонентов.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Является обязательной для конструктора форм Windows Forms
    Private components As System.ComponentModel.IContainer

    'Примечание: следующая процедура является обязательной для конструктора форм Windows Forms
    'Для ее изменения используйте конструктор форм Windows Form.  
    'Не изменяйте ее в редакторе исходного кода.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim ReportDataSource2 As Microsoft.Reporting.WinForms.ReportDataSource = New Microsoft.Reporting.WinForms.ReportDataSource()
        Me.ReportViewer1 = New Microsoft.Reporting.WinForms.ReportViewer()
        Me.U4et_oborudovanieDataSet = New Uchet_oborudovanie.U4et_oborudovanieDataSet()
        Me.report_spicanieBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.report_spicanieTableAdapter = New Uchet_oborudovanie.U4et_oborudovanieDataSetTableAdapters.report_spicanieTableAdapter()
        CType(Me.U4et_oborudovanieDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.report_spicanieBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ReportViewer1
        '
        Me.ReportViewer1.Dock = System.Windows.Forms.DockStyle.Fill
        ReportDataSource2.Name = "DataSet1"
        ReportDataSource2.Value = Me.report_spicanieBindingSource
        Me.ReportViewer1.LocalReport.DataSources.Add(ReportDataSource2)
        Me.ReportViewer1.LocalReport.ReportEmbeddedResource = "Uchet_oborudovanie.Report4.rdlc"
        Me.ReportViewer1.Location = New System.Drawing.Point(0, 0)
        Me.ReportViewer1.Name = "ReportViewer1"
        Me.ReportViewer1.Size = New System.Drawing.Size(543, 364)
        Me.ReportViewer1.TabIndex = 0
        '
        'U4et_oborudovanieDataSet
        '
        Me.U4et_oborudovanieDataSet.DataSetName = "U4et_oborudovanieDataSet"
        Me.U4et_oborudovanieDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'report_spicanieBindingSource
        '
        Me.report_spicanieBindingSource.DataMember = "report_spicanie"
        Me.report_spicanieBindingSource.DataSource = Me.U4et_oborudovanieDataSet
        '
        'report_spicanieTableAdapter
        '
        Me.report_spicanieTableAdapter.ClearBeforeFill = True
        '
        'Form9
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(543, 364)
        Me.Controls.Add(Me.ReportViewer1)
        Me.Name = "Form9"
        Me.Text = "Cписок  товаров на списание"
        CType(Me.U4et_oborudovanieDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.report_spicanieBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents ReportViewer1 As Microsoft.Reporting.WinForms.ReportViewer
    Friend WithEvents report_spicanieBindingSource As BindingSource
    Friend WithEvents U4et_oborudovanieDataSet As U4et_oborudovanieDataSet
    Friend WithEvents report_spicanieTableAdapter As U4et_oborudovanieDataSetTableAdapters.report_spicanieTableAdapter
End Class
