﻿Public Class Form3
    Private Sub ПоставкаBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles ПоставкаBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.ПоставкаBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.U4et_oborudovanieDataSet)

    End Sub

    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: данная строка кода позволяет загрузить данные в таблицу "U4et_oborudovanieDataSet.Оборудование". При необходимости она может быть перемещена или удалена.
        Me.ОборудованиеTableAdapter.Fill(Me.U4et_oborudovanieDataSet.Оборудование)
        'TODO: данная строка кода позволяет загрузить данные в таблицу "U4et_oborudovanieDataSet.Поставщик". При необходимости она может быть перемещена или удалена.
        Me.ПоставщикTableAdapter.Fill(Me.U4et_oborudovanieDataSet.Поставщик)
        'TODO: данная строка кода позволяет загрузить данные в таблицу "U4et_oborudovanieDataSet.Поставка". При необходимости она может быть перемещена или удалена.
        Me.ПоставкаTableAdapter.Fill(Me.U4et_oborudovanieDataSet.Поставка)

    End Sub
End Class